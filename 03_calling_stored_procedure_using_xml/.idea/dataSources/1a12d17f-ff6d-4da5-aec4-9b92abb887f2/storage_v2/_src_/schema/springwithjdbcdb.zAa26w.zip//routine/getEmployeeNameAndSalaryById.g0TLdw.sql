create procedure getEmployeeNameAndSalaryById(IN emp_id int, OUT emp_sal double, OUT emp_name varchar(100))
BEGIN
  SELECT employee_name,salary INTO emp_name,emp_sal FROM employee_table WHERE employee_id=emp_id;
END;

